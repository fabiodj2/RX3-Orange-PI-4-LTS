#!/usr/bin/env python3
"""Feed the RX3 native key queue from a Pioneer DDJ-400's raw MIDI stream.

Adapted from flx6-rx3.py (xsploit/rx3-pi, branch opus/human-friendly-setup).
Reads the official Mixxx Pioneer-DDJ-400.midi.xml mapping (script prefix
"PioneerDDJ400") instead of BiteDJ's FLX6 mapping. Input only; hot-cue,
beat-loop and default beat-jump banks supported. LED feedback pending.

Every (status, note) address and native RX3 code below was verified against
the real controller mapping shipped in mixxxdj/mixxx (res/controllers/
Pioneer-DDJ-400.midi.xml, cloned 2026-09-16) and cross-checked with the RX3
native codes already proven working in flx6-rx3.py. See DDJ400-PORT-NOTES.md
in this same delivery for the full function-by-function diff against FLX6,
including everything intentionally left unmapped and why.
"""
import argparse, ctypes, errno, json, os, re, signal, struct, subprocess, time
import xml.etree.ElementTree as ET

# Native RX3 key/command codes. These come from the firmware itself, not
# from the controller, so every code below is unchanged from flx6-rx3.py.
BUTTONS={'play':0x4101,'cue_default':0x4102,'loop_in':0x410c,'loop_out':0x410d,
 'reloop_toggle':0x410e,'sync_enabled':0x4112,'sync_leader':0x4111,
 'PioneerDDJ400.cycleTempoRange':0x4107,'PioneerDDJ400.toggleQuantize':0x410b,
 'pfl':0x5020,'LoadSelectedTrack':0x4311,
 'MoveFocusForward':0x420c,'MoveFocusBackward':0x420d,
 'PioneerDDJ400.shiftPressed':0x4103,
 # Confirmed on-hardware short/long-press split (controller sends distinct
 # notes 0x58 vs 0x5C for DECK1/2 - see DDJ400-PORT-NOTES.md). This covers
 # what FLX6's two separate SYNC/MASTER buttons did with a single DDJ-400
 # SYNC button.
 'PioneerDDJ400.syncPressed':0x4112,'PioneerDDJ400.syncLongPressed':0x4111}
ANALOG={'pregain':0x5019,'parameter3':0x501a,'parameter2':0x501b,'parameter1':0x501c,
 'volume':0x501e,'super1':0x509d,'crossfader':0x6017,'headMix':0x4405}
PAD_BANKS={"pad-hotcue":0,"pad-beatloop":1,"pad-beatjump":3}
LOOP_SIZES=("0.25","0.5","1","2","4","8","16","32")

# NOT mapped yet - see DDJ400-PORT-NOTES.md "Pendencias" for why each one
# is left out instead of guessed:
#   slip_enabled, sync_leader-as-dedicated-button, keylock, PrepareView,
#   PrepareToggle  -> no physical button on the DDJ-400 at all (FLX6-only
#                     hardware); need a deliberate SHIFT-combo decision
#                     with the unit in hand, not a guess from the XML alone.
#   quickJumpBack/Forward, cueLoopCallLeft/Right, toggleLoopAdjustIn/Out,
#   increase/decreaseBeatjumpSizes, beatFx*, pad-sampler bank
#                     -> hardware buttons exist and have real, distinct MIDI
#                        addresses (confirmed in the XML), but the matching
#                        RX3 *native* command/bank number is not confirmed
#                        anywhere in this repo. Wiring these up needs the
#                        native code identified first (see notes doc).

class Bridge:
 def __init__(self,xml,emit,clock=time.monotonic):
  self.clock=clock;self.jogs={ch:dict(total=0,delta=0,last=clock(),moved=0,speed=0) for ch in (1,2)}
  self.emit=emit;self.mapping={};self.msb={};self.held=set();self.pad_held={};self.status=None;self.data=[]
  self.shift={1:False,2:False}
  self.grid_ticks={1:0,2:0}
  for c in ET.parse(xml).findall('.//controls/control'):
   g=c.findtext('group','');key=c.findtext('key','');match=re.search(r'\[Channel(\d)\]',g)
   if match:
    channel=int(match[1])
    if channel>2:continue
   elif g in ('[Master]','[Library]','[Tab]'):channel=0
   else:continue
   mode='button';native=BUTTONS.get(key)
   if key=='PioneerDDJ400.shiftPressed':mode='shift'
   if g=='[Library]' and key=='MoveFocusForward':native=0x420c;mode='browse-push'
   if key=='MoveFocusBackward':native=0x420d;mode='back'
   if g=='[Library]' and key=='MoveVertical':native=0x420c;mode='relative'
   if key in ANALOG:native=ANALOG[key];mode='analog'
   if key=='PioneerDDJ400.jogTurn':native=0x4305;mode='jog'
   if key=='PioneerDDJ400.jogSearch':native=0;mode='grid-jog'
   if key=='PioneerDDJ400.jogTouch' and int(c.findtext('midino'),0)==0x36:native=0x4306
   if key=='PioneerDDJ400.tempoSliderMSB':native=0x4109;mode='tempo-msb'
   if key=='PioneerDDJ400.tempoSliderLSB':native=0x4109;mode='tempo-lsb'
   pad=re.fullmatch(r'hotcue_([1-8])_activate',key)
   if pad:native=0x4116+int(pad[1]);mode="pad-hotcue"
   if key=="PioneerDDJ400.beatjumpPadPressed":
    note=int(c.findtext("midino"),0)
    if 0x20<=note<=0x27:native=0x4117+note-0x20;mode="pad-beatjump"
   loop=re.fullmatch(r'beatloop_(0\.25|0\.5|1|2|4|8|16|32)_toggle',key)
   if loop:native=0x4117+LOOP_SIZES.index(loop[1]);mode="pad-beatloop"
   if native is None:continue
   opts={o.tag for o in c.findall('./options/*')}
   if 'fourteen-bit-msb' in opts:mode='msb'
   if 'fourteen-bit-lsb' in opts:mode='lsb'
   addr=(int(c.findtext('status'),0),int(c.findtext('midino'),0))
   item=(native,channel,mode)
   if addr in self.mapping and self.mapping[addr]!=item:raise ValueError(f'Conflicting mapping {addr}')
   self.mapping[addr]=item
 def message(self,status,note,value):
  off=status&0xf0==0x80
  if off:status+=0x10;value=0
  item=self.mapping.get((status,note))
  if not item:return
  key,ch,mode=item
  if mode=='browse-push':
   if value:self.emit(key,0,ch,0,0.,0x4250)
  elif mode=='back':
   if value:self.emit(key,0,ch,0,0.,0x424b)
  elif mode=='shift':
   down=bool(value);self.shift[ch]=down
   self.grid_ticks[ch]=0
   if down:
    self.stop_jog(ch)
    if (0x4306,ch) in self.held:
     self.emit(0x4306,2,ch,0,0.,0);self.held.discard((0x4306,ch))
   if down:self.held.add((key,ch))
   else:self.held.discard((key,ch))
   self.emit(key,0 if down else 2,ch,0,0.,0)
  elif mode=='grid-jog':self.grid_jog(ch,value)
  elif mode=='jog':
   if self.shift[ch]:self.grid_jog(ch,value);return
   j=self.jogs[ch];delta=value-64
   if delta:j['delta']+=delta;j['total']+=delta;j['moved']=self.clock()
  elif mode in PAD_BANKS:
   bank=PAD_BANKS[mode];identity=(key,ch)
   if value:
    if self.pad_held.get(identity)==bank:return
    for (old_key,old_ch),old_bank in list(self.pad_held.items()):
     if old_ch==ch and old_bank!=bank:
      self.emit(old_key,2,ch,0,0.,0x5040|old_bank)
      del self.pad_held[(old_key,ch)];self.held.discard((old_key,ch))
    self.pad_held[identity]=bank;self.held.add(identity)
    self.emit(key,0,ch,0,0.,0x5040|bank)
   elif self.pad_held.get(identity)==bank:
    del self.pad_held[identity];self.held.discard(identity)
    self.emit(key,2,ch,0,0.,0x5040|bank)
  elif mode=='button':
   op=0 if value else 2
   if key==0x4306 and self.shift[ch]:return
   if key==0x4306 and op==2:self.stop_jog(ch)
   if op==0:self.held.add((key,ch))
   else:self.held.discard((key,ch))
   self.emit(key,op,ch,0,0.,0)
  elif mode=='relative':
   delta=value if value<64 else value-128
   if delta:self.emit(key,4,ch,delta,0.,0x4252) # browser-only encoder intent
  elif mode in ('msb','tempo-msb'):self.msb[(status,note)]=value
  elif mode=='tempo-lsb':
   hi=self.msb.get((status,note-32))
   if hi is not None:self.emit(key,5,ch,0,((hi<<7)|value)/8192.-1.,0x544d)
  elif mode=='lsb':
   hi=self.msb.get((status,note-32))
   if hi is not None:self.emit(key,4,ch,0,((hi<<7)|value)/16383.,0)
  else:self.emit(key,4,ch,0,value/127.,0)
 def feed(self,data):
  for b in data:
   if b>=0xf8:continue
   if b&0x80:
    self.data=[];self.status=b if b<0xf0 else None
   elif self.status is not None:
    self.data.append(b)
    n=1 if self.status&0xf0 in (0xc0,0xd0) else 2
    if len(self.data)==n:
     if n==2:self.message(self.status,*self.data)
     self.data=[]
 def grid_jog(self,ch,value):
  total=self.grid_ticks[ch]+value-64
  steps=abs(total)//16*(1 if total>=0 else -1)
  self.grid_ticks[ch]=total-steps*16
  # RX3 offset units are quarter milliseconds; 5 ms per step (same ratio
  # used for FLX6 in flx6-rx3.py; DDJ-400 shift-jog search sends the same
  # 0-127 relative CC shape, so the same divisor applies - not yet verified
  # on real hardware, see DDJ400-PORT-NOTES.md).
  if steps:self.emit(0,4,ch,steps*20,0.,0x4744)
 def pulse(self,ch):
  # RX3 hardware uses 1620 pulses/revolution. DDJ-400's jog wheel resolution
  # is assumed identical to the FLX6's (7200) since both are standard
  # Pioneer optical encoders - NOT independently confirmed, see notes doc.
  return round(self.jogs[ch]['total']*1620/7200)&65535
 def stop_jog(self,ch):
  j=self.jogs[ch];self.emit(0x4305,4,ch,0,0.,self.pulse(ch));j['delta']=0;j['speed']=0;j['last']=self.clock()
 def tick(self):
  now=self.clock()
  for ch,j in self.jogs.items():
   elapsed=now-j['last']
   if elapsed<.01:continue
   if j['delta']:
    speed=j['delta']*1.8/(7200*elapsed)
    self.emit(0x4305,4,ch,0,speed,self.pulse(ch))
    j['delta']=0;j['speed']=speed;j['last']=now
   elif j['speed'] and now-j['moved']>=.04:self.stop_jog(ch)
   elif not j['speed']:j['last']=now
 def release(self):
  for ch,j in self.jogs.items():
   if j['speed'] or j['delta']:self.stop_jog(ch)
  for key,ch in list(self.held):self.emit(key,2,ch,0,0.,0)
  self.held.clear();self.pad_held.clear()
  for ch in self.shift:self.shift[ch]=False;self.grid_ticks[ch]=0
def listen_reconnecting(b,lib,running,discover,sleep=time.sleep):
 """Release controller gestures on loss; rediscover ALSA numbering on return."""
 buf=ctypes.create_string_buffer(1024)
 waiting=False
 while running():
  handle=ctypes.c_void_p()
  try:
   devices=discover()
   if len(devices)!=1:raise OSError(errno.ENODEV,'Expected one DDJ-400 MIDI input')
   rc=lib.snd_rawmidi_open(ctypes.byref(handle),None,devices[0].encode(),2)
   if rc<0:raise OSError(-rc,'Cannot open DDJ-400 MIDI input')
  except (OSError,subprocess.SubprocessError) as e:
   if not waiting:print(f'Waiting for DDJ-400 MIDI: {e}',flush=True)
   waiting=True
   for _ in range(20):
    if not running():break
    sleep(.05)
   continue
  waiting=False
  print(f'Listening to {devices[0]} (input only)',flush=True)
  try:
   while running():
    n=lib.snd_rawmidi_read(handle,buf,len(buf))
    if n>0:b.feed(buf.raw[:n])
    elif n in (0,-errno.EAGAIN):sleep(.005)
    elif n!=-errno.EINTR:
     print(f'DDJ-400 MIDI read failed ({n}); reconnecting',flush=True)
     break
    b.tick()
  finally:
   try:b.release()
   finally:
    lib.snd_rawmidi_close(handle)
    b.status=None;b.data=[];b.msb.clear()
  for _ in range(20):
   if not running():break
   sleep(.05)
def main():
 runtime=os.environ.get('RX3_RUNTIME')
 p=argparse.ArgumentParser();p.add_argument('--mapping',default=os.path.expanduser('~/.mixxx/controllers/Pioneer-DDJ-400.midi.xml'))
 p.add_argument('--fifo',default=runtime and os.path.join(runtime,'dev/rx3-control'),help='runtime dev/rx3-control (default from RX3_RUNTIME)')
 p.add_argument('--player-id',help='launcher identity for this player session')
 p.add_argument('--state',help='jog counter file kept across bridge restarts')
 p.add_argument('--port-name',default='DDJ-400',help='MIDI port name shown by amidi -l')
 p.add_argument('--replay');p.add_argument('--dry-run',action='store_true')
 p.add_argument('--check-mapping',action='store_true',help='only load the mapping and report the binding count');a=p.parse_args()
 if a.check_mapping:
  print(f'Loaded {len(Bridge(a.mapping,lambda *c:None).mapping)} MIDI bindings from {a.mapping}');return
 if not a.dry_run and not a.fifo:p.error('--fifo is required (or set RX3_RUNTIME)')
 fd=None if a.dry_run else os.open(a.fifo,os.O_RDWR|os.O_NONBLOCK)
 def emit(*cmd):
  if fd is not None:os.write(fd,struct.pack('<iiiifi',*cmd))
  if a.replay or a.dry_run:print(cmd,flush=True)
 b=Bridge(a.mapping,emit);print(f'Loaded {len(b.mapping)} MIDI bindings from {a.mapping}',flush=True)
 if a.replay:
  b.feed(open(a.replay,'rb').read());b.release();return
 player=a.player_id or subprocess.check_output(['pgrep','-x','rbp-pi'],text=True).strip()
 statefile=a.state or os.path.join(os.path.dirname(a.fifo or '.'),'rx3-midi-jog-state.json')
 try:
  previous=json.load(open(statefile))
  if previous.get('player')==player:
   for ch in (1,2):b.jogs[ch]['total']=int(previous['totals'][str(ch)])
 except (OSError,ValueError,KeyError,TypeError):pass
 lib=ctypes.CDLL('libasound.so.2');handle=ctypes.c_void_p()
 lib.snd_rawmidi_open.argtypes=[ctypes.POINTER(ctypes.c_void_p),ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int]
 lib.snd_rawmidi_read.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t];lib.snd_rawmidi_read.restype=ctypes.c_ssize_t
 lib.snd_rawmidi_close.argtypes=[ctypes.c_void_p]
 def discover():
  listing=subprocess.check_output(['amidi','-l'],text=True)
  return re.findall(r'^I[O ]\s+(hw:\S+)\s+.*'+re.escape(a.port_name),listing,re.M)
 running=True
 def stop(*_):
  nonlocal running
  running=False
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  listen_reconnecting(b,lib,lambda:running,discover)
 finally:
  b.release()
  with open(statefile+'.tmp','w') as f:json.dump({'player':player,'totals':{ch:j['total'] for ch,j in b.jogs.items()}},f)
  os.replace(statefile+'.tmp',statefile)
  if fd is not None:os.close(fd)
if __name__=='__main__':main()
